//
//  main.m
//  IDWebServiceDemo
//
//  Created by SCMS MAC MINI 1 on 18/05/15.
//  Copyright (c) 2015 SCMS MAC MINI 1. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

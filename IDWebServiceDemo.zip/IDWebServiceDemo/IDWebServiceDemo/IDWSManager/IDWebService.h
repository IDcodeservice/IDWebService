//
//  IDWebService.h
//  IDVersion:1.0
//  Copyright (c) 2014 ID Developer Team
//  By Prashant
//

#import <Foundation/Foundation.h>
#import "IDWebRequestManager.h"

@interface IDWebService : NSObject

//Set Base URL
extern NSString *const IDBaseURL;

//set Service URL
extern NSString *const IDServiceURl;


@end

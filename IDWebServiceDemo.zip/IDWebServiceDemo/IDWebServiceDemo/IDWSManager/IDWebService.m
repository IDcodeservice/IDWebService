//
//  IDWebService.m
//  IDVersion:1.0
//  Copyright (c) 2014 ID Developer Team
//  By Prashant
//

#import "IDWebService.h"

@implementation IDWebService


//Set Base URL
NSString *const IDBaseURL = @"http://api.openweathermap.org/data/2.5/";

//set Service URL
NSString *const IDServiceURl = @"weather";
@end

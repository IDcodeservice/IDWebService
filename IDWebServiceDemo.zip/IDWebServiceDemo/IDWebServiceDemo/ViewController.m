//
//  ViewController.m
//  IDWebServiceDemo
//
//  Created by SCMS MAC MINI 1 on 18/05/15.
//  Copyright (c) 2015 SCMS MAC MINI 1. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



-(void)callService
{
    NSMutableDictionary *postDic=[[NSMutableDictionary alloc]init];
    [postDic setObject:@"delhi,india" forKey:@"q"];
    
    [IDWebServiceManager IDWSManager:postDic IDServiceURL:IDServiceURl IDCurrentView:self.view IDIsRequestGET:YES IDIsLoader:YES callback:^(NSError *IDError, IDWebServiceManager *IDWSManager) {
        if (IDError)
        {
            NSLog(@"error==>%@",IDError);
        }
        else
        {
            NSLog(@"IDResult===>%@",IDWSManager.IDResult);
        }
    }];
}

- (IBAction)btnclick:(id)sender
{
    [self callService];
}
@end
